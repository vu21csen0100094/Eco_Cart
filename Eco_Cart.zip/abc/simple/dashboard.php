<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
include("main.php");
?>