<!DOCTYPE html>
<html>
<head>
    <title>Search in JavaScript</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .hidden { display: none; }
    </style>
</head>
<body>
<div class="container">
  <div class="navbar">
    <div class="logo">
      <a href="index.html"><img src="../image/logo.png" alt="Eco_Cart" width="125px" /></a>
    </div>

    <section>
        <div class="search">
            <div class="icon"></div>

            <div class="input">
                <input type="text" placeholder="Search..." id="mysearch" onkeyup="filterProducts()">
            </div>

            <span class="clear" onclick="document.getElementById('mysearch').value = ''; filterProducts()">x</span>
        </div>
    </section>

    <nav>
      <ul id="MenuItems">
        <li><a href="../contact.html">Contact</a></li>
        <li><a href="account.html">Account</a></li>
        <li><a href="../index.html">Logout</a></li>
      </ul>
    </nav>
    <a href="../cart.html">
    <img src="https://i.ibb.co/PNjjx3y/cart.png" alt="" width="30px" height="30px" />
    <span class="cart-count">0</span>
</a>
    </div>
</div>

<div class="small-container" id="productContainer">
  <div class="row">
    <div class="col-4" data-name="Bag" data-price="500.00">
      <img src="../image/bag.jpg" alt="" />
      <h4>Bag</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
      <button class="add-to-cart">Add to Cart</button>
    </div>

    <div class="col-4" data-name="Syrum" data-price="500.00">
      <img src="../image/syrum.jpg" alt="" />
      <h4>Syrum</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
      <button class="add-to-cart">Add to Cart</button>
    </div>

    <div class="col-4" data-name="Buds" data-price="500.00">
      <img src="../image/buds.jpg" alt="" />
      <h4>Buds</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
      </div>
      <p>₹500.00</p>
      <button class="add-to-cart">Add to Cart</button>
    </div>

    <div class="col-4" data-name="Bottle" data-price="500.00">
      <img src="../image/bottle.jpg" alt="" />
      <h4>Bottle</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
      <button class="add-to-cart">Add to Cart</button>
    </div>
  </div>

  <!-- Add other product rows similarly with the data-price attribute -->
  
  <div class="page-btn">
    <span>1</span>
    <span>2</span>
    <span>3</span>
    <span>4</span>
    <span>&#8594;</span>
  </div>
</div>

<!-- Footer -->
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="footer-col-1">
        <h3>Download Our App</h3>
        <p>Download App for Android and iso mobile phone.</p>
        <div class="app-logo">
          <img src="https://i.ibb.co/KbPTYYQ/play-store.png" alt="" />
          <img src="https://i.ibb.co/hVM4X2p/app-store.png" alt="" />
        </div>
      </div>

      <div class="footer-col-2">
        <img src="https://i.ibb.co/j3FNGj7/logo-white.png" alt="" />
        <p>
          Our Purpose Is To Sustainably Make the Pleasure and Benefits of
          Sports Accessible to the Many.
        </p>
      </div>

      <div class="footer-col-3">
        <h3>Useful Links</h3>
        <ul>
          <li>Coupons</li>
          <li>Blog Post</li>
          <li>Return Policy</li>
          <li>Join Affiliate</li>
        </ul>
      </div>

      <div class="footer-col-4">
        <h3>Follow us</h3>
        <ul>
          <li>Facebook</li>
          <li>Twitter</li>
          <li>Instagram</li>
          <li>YouTube</li>
        </ul>
      </div>
    </div>
    <hr />
    <p class="copyright">Copyright &copy; 2021 - Red Store</p>
  </div>
</div>

<!-- JavaScript -->
<script src="main.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productElement = button.closest('.col-4');
            const productName = productElement.dataset.name;
            const productPrice = parseFloat(productElement.dataset.price);

            if (isNaN(productPrice)) {
                alert('Price is not valid for ' + productName);
                return;
            }

            // Retrieve cart items from localStorage
            const cart = JSON.parse(localStorage.getItem('cart')) || [];

            // Check if item already exists in the cart
            const existingItemIndex = cart.findIndex(item => item.name === productName);

            if (existingItemIndex > -1) {
                // Update quantity if item already exists
                cart[existingItemIndex].quantity += 1;
            } else {
                // Add new item to the cart
                const newItem = {
                    name: productName,
                    price: productPrice,
                    quantity: 1
                };
                cart.push(newItem);
            }

            // Save updated cart to localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
            alert(`${productName} has been added to the cart!`);
        });
    });
});
</script>

</body>
</html>
