var MenuItems = document.getElementById('MenuItems');
  MenuItems.style.maxHeight = '0px';

  function menutoggle() {
    if (MenuItems.style.maxHeight == '0px') {
      MenuItems.style.maxHeight = '200px';
    } else {
      MenuItems.style.maxHeight = '0px';
    }
  }
  const icon = document.querySelector(".icon");
const search = document.querySelector(".search");

icon.onclick = function () {
	search.classList.toggle("active");
};

function filterProducts() {
  const searchInput = document.getElementById('mysearch').value.toLowerCase();
  const products = document.querySelectorAll('.col-4');
  
  products.forEach(product => {
      const productName = product.getAttribute('data-name').toLowerCase();
      if (productName.includes(searchInput)) {
          product.classList.remove('hidden');
      } else {
          product.classList.add('hidden');
      }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  let cartCount = 0;
  const cartCountElement = document.querySelector('.cart-count');
  const addToCartButtons = document.querySelectorAll('.add-to-cart');

  addToCartButtons.forEach(button => {
      button.addEventListener('click', () => {
          cartCount++;
          cartCountElement.textContent = `${cartCount}`;
      });
  });
});

