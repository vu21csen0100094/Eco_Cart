<?php 
 
 $con = mysqli_connect("localhost","root","12345678","ecocart") or die("Couldn't connect");

?>