function search() {
    let filter = document.getElementById('find').value.toUpperCase();
    let items = document.querySelectorAll('.product');
    items.forEach(item => {
        let productName = item.getElementsByTagName('h3')[0].innerText.toUpperCase();
        if (productName.indexOf(filter) > -1) {
            item.style.display = "";
        } else {
            item.style.display = "none";
        }
    });
}

function login() {
    alert('Login functionality to be implemented.');
}

let cart = [];

function addToCart(productName, productPrice) {
    cart.push({ name: productName, price: productPrice });
    document.getElementById('cart-count').innerText = cart.length;
    updateCart();
}

function toggleCart() {
    const cartElement = document.getElementById('cart');
    cartElement.style.display = cartElement.style.display === 'block' ? 'none' : 'block';
}

function updateCart() {
    const cartItemsElement = document.getElementById('cart-items');
    cartItemsElement.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price;

        const li = document.createElement('li');
        li.innerHTML = `${item.name} - ₹${item.price.toFixed(2)} <button onclick="removeFromCart(${index})">Remove</button>`;
        cartItemsElement.appendChild(li);
    });

    document.getElementById('cart-total').innerText = `Total: ₹${total.toFixed(2)}`;
}

function removeFromCart(index) {
    cart.splice(index, 1);
    document.getElementById('cart-count').innerText = cart.length;
    updateCart();
}

function checkout() {
    alert('Checkout functionality to be implemented.');
}
